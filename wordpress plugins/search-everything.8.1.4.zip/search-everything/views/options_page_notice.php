<div class="updated" id="se-top-notice" >
	<a href="<?php echo $close_url; ?>" style="position: absolute; right: 30px; top: 20px;">Dismiss</a>
	<h3>Good news everyone!</h3>
	<p class="about-description">Search Everything has been upgraded with security updates and some exciting new features. Visit settings to learn more.</p>
</div>

