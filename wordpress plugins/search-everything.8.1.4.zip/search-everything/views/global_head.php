<script type="text/javascript">
	window._se_plugin_version = '<?php echo SE_VERSION; ?>';
</script>
