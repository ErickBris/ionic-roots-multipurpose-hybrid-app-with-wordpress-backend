<?php
/*
 * Plugin Name: Roots controllers for JSON API
 * Version: 1.0
 * Plugin URI: http://www.studio31.co/
 * Description: Extends the functionality of JSON API
 * Author: Adan Archila
 * Author URI: http://www.studio31.co
 * Requires at least: 4.0
 * Tested up to: 4.0
 *
 * @package WordPress
 * @author Adan Archila
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

add_filter( 'json_api_controllers', 'add_roots_controller' );
add_filter( 'json_api_roots_controller_path', 'set_roots_controller_path' );


function add_roots_controller( $controllers ) {
  $controllers[] = 'Roots';
  return $controllers;
}
  
function set_roots_controller_path() {
  return PLUGIN_DIR . '/controllers/Roots.php';
}