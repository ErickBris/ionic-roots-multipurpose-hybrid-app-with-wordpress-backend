Roots extends JSON API
=========================

Extends some functions to the JSON API plugin.