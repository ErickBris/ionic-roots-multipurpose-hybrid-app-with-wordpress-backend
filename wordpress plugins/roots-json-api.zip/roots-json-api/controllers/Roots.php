<?php

/*
  Controller name: Roots
  Controller description: Extend the functionality of JSON API for Roots Hybrid App.
  Controller Author: Adan Archila
  Controller Author Website: studio31.co
  
*/
class JSON_API_Roots_Controller {

	public function get_categories() {

	    global $json_api;

        $args = array();

	    $image_size = 'full';

        $url = parse_url($_SERVER['REQUEST_URI']);
        $query = wp_parse_args($url['query']);
        unset($query['json']);

        $args = array_merge($args, $query);

	    if (!empty($json_api->query->parent)) {
	      $args['parent'] =  $json_api->query->parent;	   
	    }
	    
	    if(!empty($json_api->query->image_size)) {
	    	$image_size = $json_api->query->image_size;
	    }

	    $wp_categories = get_categories($args);

	    $categories = array();
	    foreach ($wp_categories as $wp_category) {
	      if ($wp_category->term_id == 1 && $wp_category->slug == 'uncategorized') {
	        continue;
	      }
	      $categories[] = $this->prepare_category($wp_category, $image_size);
	    }

	    return array(
	      'count' => count($categories),
	      'categories' => $categories
	    );

	}

	protected function prepare_category($wp_category, $image_size) {

		$image = '';

		if(function_exists(z_taxonomy_image_url)){
			$image = z_taxonomy_image_url($wp_category->term_id, $image_size);
		}

		return array(
			'id' => (int) $wp_category->term_id,
			'slug' => $wp_category->slug,
			'title' => $wp_category->name,
			'description' => $wp_category->description,
			'parent' => (int) $wp_category->parent,
			'post_count' => (int) $wp_category->count,
			'image' => $image
		);

	}

	public function get_photos() {

		global $json_api;

		if (!$json_api->query->gallery_id) {
			$json_api->error("You must include a 'gallery_id' value to get the photos.", 403);
		}

	    $defaults = array(
			'ignore_sticky_posts' => true,
			'post_type' => 'gallery',
			'custom_field' => 'photos',
			'post__in' => array( $json_api->query->gallery_id )
	    );

	   	if (!empty($json_api->query->post_type)) {
	      $defaults = array(
	        'post_type' => $json_api->query->post_type
	      );
	    }

	    if (!empty($json_api->query->custom_field)) {
	      $defaults = array(
	        'custom_field' => $json_api->query->custom_field
	      );
	    }

	    $posts = $json_api->introspector->get_posts($defaults);
	    $result = $this->photo_results($posts, $defaults['custom_field']);
    	return $result;

	}	

	protected function photo_results($posts, $custom_field) {

		$photo_ids = $posts[0]->custom_fields->{$custom_field}[0];

		if(is_serialized($posts[0]->custom_fields->{$custom_field}[0])){
			$photo_ids = unserialize( $photo_ids );
		}
		
		$photos = array();
		$counter = 0;
		foreach($photo_ids as $photo_id){
			$photos[] = wp_prepare_attachment_for_js($photo_id, true);
		}

		return array(
			'photos' => $photos
		);
	}

	// Some of the code found at http://wordpress.stackexchange.com/a/18200/6084
	// Coded by Hameedullah Khan

    public function get_posts() {
        global $json_api;

        $url = parse_url($_SERVER['REQUEST_URI']);

        $defaults = array(
          'ignore_sticky_posts' => true
        );

        $query = wp_parse_args($url['query']);
        unset($query['json']);
        unset($query['post_status']);
        $query = array_merge($defaults, $query);
        $posts = $json_api->introspector->get_posts($query);

        foreach ($posts as $jpost) { // search for "image" custom field and replace it with the url of the image
            $this->imageCustomfield( $jpost );
        }

        $result = $this->posts_result($posts);
        $result['query'] = $query;
        return $result;
    }

    protected function imageCustomfield( $post ){
        $custom_fields = $post->custom_fields;
        $new_custom_fields = '';
        foreach($post->custom_fields as $custom_field => $value){

            if (strpos($custom_field, 'image') !== false) {
                $new_custom_fields[$custom_field] = wp_prepare_attachment_for_js($value[0]);
            } else {
                $new_custom_fields[$custom_field] = $value;
            }
        }
        $post->custom_fields = $new_custom_fields;
        return $post;
    }

    protected function posts_result($posts) {
        global $wp_query;
        return array(
            'count' => count($posts),
            'count_total' => (int) $wp_query->found_posts,
            'pages' => $wp_query->max_num_pages,
            'posts' => $posts
        );
    }

    protected function add_taxonomies( $post ) {
        $taxonomies = get_object_taxonomies( $post->type );
        foreach ($taxonomies as $tax) {
            $post->$tax = array();
            $terms = wp_get_object_terms( $post->id, $tax );
            foreach ( $terms as $term ) {
                $post->{$tax}[] = $term->name;
            }
        }
        return true;
    }

    public function get_taxonomy_posts() {
        global $json_api;
        $taxonomy = $this->get_current_taxonomy();
        if (!$taxonomy) {
            $json_api->error("Not found.");
        }
        $term = $this->get_current_term( $taxonomy );
        $posts = $json_api->introspector->get_posts(array(
                    'taxonomy' => $taxonomy,
                    'term' => $term->slug
                ));
        foreach ($posts as $jpost) {
            $this->add_taxonomies( $jpost );
            $this->imageCustomfield( $jpost );
        }
        return $this->posts_object_result($posts, $taxonomy, $term);
    }

    protected function get_current_taxonomy() {
        global $json_api;
        $taxonomy  = $json_api->query->get('taxonomy');
        if ( $taxonomy ) {
            return $taxonomy;
        } else {
            $json_api->error("Include 'taxonomy' var in your request.");
        }
        return null;
    }

    protected function get_current_term( $taxonomy=null ) {
        global $json_api;
        extract($json_api->query->get(array('id', 'slug', 'term_id', 'term_slug')));
        if ($id || $term_id) {
            if (!$id) {
                $id = $term_id;
            }
            return $this->get_term_by_id($id, $taxonomy);
        } else if ($slug || $term_slug) {
            if (!$slug) {
                $slug = $term_slug;
            }
            return $this->get_term_by_slug($slug, $taxonomy);
        } else {
            $json_api->error("Include 'id' or 'slug' var for specifying term in your request.");
        }
        return null;
    }

    protected function get_term_by_id($term_id, $taxonomy) {
        $term = get_term_by('id', $term_id, $taxonomy);
        if ( !$term ) return null;
        return new JSON_API_Term( $term );
    }

    protected function get_term_by_slug($term_slug, $taxonomy) {
        $term = get_term_by('slug', $term_slug, $taxonomy);
        if ( !$term ) return null;
        return new JSON_API_Term( $term );
    }

    protected function posts_object_result($posts, $taxonomy, $term) {
        global $wp_query;
        return array(
          'count' => count($posts),
          'pages' => (int) $wp_query->max_num_pages,
          'taxonomy' => $taxonomy,
          'term' => $term,
          'posts' => $posts
        );
    }

    public function get_search_results() {
        global $json_api;
        if ($json_api->query->search) {
          $posts = $json_api->introspector->get_posts(array(
            's' => $json_api->query->search
          ));
        } else {
          $json_api->error("Include 'search' var in your request.");
        }
        foreach ($posts as $jpost) { // search for "image" custom field and replace it with the url of the image
            $this->imageCustomfield( $jpost );
        }
        return $this->posts_result($posts);
      }

}


// Generic rewrite of JSON_API_Tag class to represent any term of any type of taxonomy in WP
class JSON_API_Term {

  var $id;          // Integer
  var $slug;        // String
  var $title;       // String
  var $description; // String

  function JSON_API_Term($term = null) {
    if ($term) {
      $this->import_wp_object($term);
    }
  }

  function import_wp_object($term) {
    $this->id = (int) $term->term_id;
    $this->slug = $term->slug;
    $this->title = $term->name;
    $this->description = $term->description;
    $this->post_count = (int) $term->count;
  }

}
